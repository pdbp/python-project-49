### Demonstrations:

brain-even: https://asciinema.org/a/BfY3Mi6QAnNV6hZXc7QIGaYUS
brain-calc: https://asciinema.org/a/abszUwE5UONEAGYH9oyPpTBXx

### Hexlet tests and linter status:

[![Actions Status](https://github.com/pdbp/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/pdbp/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e1b5791c9aec70d2a3a1/maintainability)](https://codeclimate.com/github/pdbp/python-project-49/maintainability)
